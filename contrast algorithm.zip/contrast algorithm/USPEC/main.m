% % 关闭所有警告信息
% warning('off', 'all');
% % RealWorld mat
% root_path = '../RealWorld_section/';
% filename = 'wine.mat';
% filepath = fullfile(root_path, filename);
% data1=load(filepath);
% keys = fieldnames(data1);
% X = data1.(keys{1});
% X = (X - min(X(:))) / (max(X(:)) - min(X(:)));
% Y = data1.(keys{2});
% [n, d] = size(X);
% fprintf('------------------------------%s: shape (%d, %d)--------------------------------\n', filename, n, d);
% cluster_num=length(unique(Y));
% for k = 3:50
%     try
%         y_predict = USPEC(X, cluster_num,'euclidean',1000,k);
%         [statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(y_predict,Y);
%         fprintf('ARI: %.2f, NMI: %.2f, ACC: %.2f, K:%d\n', ARI, NMI, ACC,k);
%     catch ME
%         continue
%     end
% end
% Synthetic数据txt
root_path = '../datasets/';
data_name = 'Aggregation';
data_labels = load(fullfile(root_path, [data_name '.txt']));
X = data_labels(:, 1:end-1);
Y = data_labels(:, end);
[n, d] = size(X);
X = (X - min(X(:))) / (max(X(:)) - min(X(:)));
cluster_num=length(unique(Y));
fprintf('------------------data_name:%s   shape:(%d,%d)   cluster_num:%d----------------\n', data_name,n,d,cluster_num);
for k = 3:50
    try
        y_predict = USPEC(X, cluster_num,'euclidean',1000,k);
        [statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(y_predict,Y);
        fprintf('ARI: %.2f, NMI: %.2f, ACC: %.2f, K:%d\n', ARI, NMI, ACC,k);
    catch ME
        continue
    end
end
%% IMG mat
% root_path = 'D:\Artificial intelligence\Machine_Learning\Data\IMG_mat/';
% filename = 'USPS.mat';
% filepath = fullfile(root_path, filename);
% data1=load(filepath);
% keys = fieldnames(data1);
% X = data1.(keys{1});
% X = (X - min(X(:))) / (max(X(:)) - min(X(:)));
% Y = data1.(keys{2});
% [n, d] = size(X);
% fprintf('------------------------------%s: shape (%d, %d)--------------------------------\n', filename, n, d);
% cluster_num=length(unique(Y));
% for k = 3:50
%     try
%         y_predict = USPEC(X, cluster_num,'euclidean',1000,k);
%         [statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(y_predict,Y);
%         fprintf('ARI: %.2f, NMI: %.2f, ACC: %.2f, K:%d\n', ARI, NMI, ACC,k);
%     catch ME
%         continue
%     end
% end