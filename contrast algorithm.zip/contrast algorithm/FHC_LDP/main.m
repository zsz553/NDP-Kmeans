% 读取整个k文件
dataset_k = readtable('D:/Artificial Intelligence/Data/dataset_k2.xlsx');
% 数据根目录
root_path = 'D:\Artificial Intelligence\Data\RealWorld_mat';
% 用于存储运行结果
df_list ={};
% 遍历并输出文件夹下的所有文件
for k = 1:height(dataset_k)
    fileName = dataset_k{k,'Var1'}{1};
    K = dataset_k{k,'Var2'};
    fullPath = fullfile(root_path, fileName);
    data1=load(fullPath);
    keys = fieldnames(data1);
    data = data1.(keys{1});
    labels = data1.(keys{2});
    [N, d] = size(data);
    if size(data,1)>3000 || K>100
        continue;
    end
    num_cluster = length(unique(labels));
    flag = 1;
    try
        [result] = FHC_LPD(data, K,num_cluster);
        [statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(labels,result);
    catch ME
        flag = 0;
    end
    if flag
        row_data = {fileName,K,ACC,NMI,ARI};
    else
        row_data = {fileName,K,'/','/','/'};
    end
    disp(row_data);
    df_list(end+1, :) = row_data;
    writecell(df_list, 'FHC_LPD.xlsx');
end