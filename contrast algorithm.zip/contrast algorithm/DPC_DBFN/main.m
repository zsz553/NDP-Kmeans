% 关闭所有警告信息
warning('off', 'all');
% % 打开文件
% fileID = fopen('../data_name.txt', 'r');
%
% % 检查文件是否成功打开
% if fileID == -1
%     error('无法打开文件');
% end
%
% % 读取文件中的所有行
% filenames = {};
% while ~feof(fileID)
%     line = fgetl(fileID);
%     if ischar(line)
%         filenames{end+1} = line;
%     end
% end
% fclose(fileID);
% root_path = 'D:\Artificial intelligence\Machine_Learning\Data\RealWorld_mat/';
% for i = 1:length(filenames)
%     filename = filenames{i};
%     filename = 'semeionEW.mat';
%     % 构造文件的完整路径（假设文件在当前目录）
%     filepath = fullfile(root_path, filename);
%     data1=load(filepath);
%     keys = fieldnames(data1);
%     X = data1.(keys{1});
%     % min-max
%     X = (X - min(X(:))) / (max(X(:)) - min(X(:)));
%     % std
%     %         X = (X - mean(X(:))) / std(X(:));
%     Y = data1.(keys{2});
%     [n, d] = size(X);
%     fprintf('------------------------------%s: shape (%d, %d)--------------------------------\n', filename, n, d);
%     cluster_num=length(unique(Y));
%     best_ACC = 0;
%     best_ARI = 0;
%     best_NMI = 0;
%     best_k = 0;
%     for k = 200:500
%         [y_predict,center] = DPC_DBFN(X,k,cluster_num);
%         [statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(y_predict,Y);
%         fprintf('ARI: %.2f, NMI: %.2f, ACC: %.2f, K:%d\n',ARI , NMI, ACC,k);
%     end
%     break;
% end



% Synthetic数据txt
% root_path = '../datasets/';
% data_name = 'Aggregation';
% data_labels = load(fullfile(root_path, [data_name '.txt']));
% X = data_labels(:, 1:end-1);
% Y = data_labels(:, end);
% X = (X - min(X(:))) / (max(X(:)) - min(X(:)));
root_path = "../RealWorld_section/";
data_name = "wine.mat";

% % 加载数据
data_labels = load(fullfile(root_path, data_name));

% 获取字段名
keys = fieldnames(data_labels);

% 提取特征矩阵 X 和标签 Y
X = double(data_labels.(keys{end-1})); % 特征矩阵
Y = double(data_labels.(keys{end}));   % 标签
Y = Y(:); % 展平为列向量
cluster_num=length(unique(Y));
best_ACC = 0;
best_ARI = 0;
best_NMI = 0;
best_k = 0;
for k = 2:100
    [y_predict,center] = DPC_DBFN(X,k,cluster_num);
    [statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(y_predict,Y);
    fprintf('ARI: %.2f, NMI: %.2f, ACC: %.2f, K:%d\n',ARI , NMI, ACC,k);
    if best_ARI+best_NMI+best_ACC<ACC+NMI+ARI
        best_ACC = ACC;
        best_ARI = ARI;
        best_NMI = NMI;
        best_k = k;
    end
end
fprintf('ARI: %.2f, NMI: %.2f, ACC: %.2f, K:%d\n',best_ARI , best_NMI, best_ACC,best_k);

