function BestMea=BestMeasure(T,DLP_Label1)
n=length(T);
NMI = get_NMI(T,DLP_Label1);
ARI =adjusted_rand_index(T,DLP_Label1,n);
acc=cluster_acc(T,DLP_Label1);
BestMea=[ARI,NMI,acc];
end