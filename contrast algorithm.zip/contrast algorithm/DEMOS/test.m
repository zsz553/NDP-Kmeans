% 读取整个k文件
dataset_k = readtable('D:/Artificial Intelligence/Data/dataset_k2.xlsx');

% 数据根目录
root_path = 'D:\Artificial Intelligence\Data\RealWorld_mat';


% 用于存储运行结果
df_list ={};
% 遍历并输出文件夹下的所有文件
for k = 1:height(dataset_k)
    fileName = dataset_k{k,'Var1'}{1};
    disp(fileName);
    K = dataset_k{k,'Var2'};
    fullPath = fullfile(root_path, fileName);
    data1=load(fullPath);
    keys = fieldnames(data1);
    data = data1.(keys{1});
    labels = data1.(keys{2});
    if length(data)>3000
        continue;
    end
    num_cluster = length(unique(labels));
    flag = 1;
    try
        [CL,rho,delta,centers,runtime] = DEMOS(data,K);
        [statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(labels,CL);
    catch ME
        flag = 0;
    end
    if flag
        row_data = {fileName,K,ACC,NMI,ARI};
    else
        row_data = {fileName,K,'/','/','/'};
    end
    disp(row_data);
    df_list(end+1, :) = row_data;
    writecell(df_list, 'DEMOS.xlsx');
end