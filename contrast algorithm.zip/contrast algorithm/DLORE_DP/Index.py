import numpy as np
from sklearn.metrics import normalized_mutual_info_score
from sklearn.metrics import adjusted_mutual_info_score, adjusted_rand_score, fowlkes_mallows_score
from scipy.optimize import linear_sum_assignment
import scipy.io as scio
import matplotlib.pyplot as plt

def compute_score(y_last, y):
    NMI = normalized_mutual_info_score(y, y_last) * 100
    ARI = adjusted_rand_score(y, y_last) * 100
    ACC = cluster_accuracy(y, y_last) * 100
    return ARI, NMI, ACC

def cluster_accuracy(y_true, y_pred):
    y_true = y_true.astype(np.int64)
    assert y_pred.size == y_true.size
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    ind = linear_sum_assignment(w.max() - w)
    ind = np.array(ind).T
    return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size



pathdata = r"C:\\Users\\jason\\Desktop\\研究生\\聚类\\聚类研究\\duck.txt"
# 读取数据
data1 = np.loadtxt(pathdata, usecols=(0, 1, 2), dtype={'names': ('x', 'y', 'label'), 'formats': ('f4', 'f4', 'S10')})
# 分离坐标和标签，其中标签可能包含字符串，例如"noise"
data = np.stack((data1['x'], data1['y']), axis=-1).astype(np.float32)
n, d = data.shape
print(n, d)
# 处理标签，将"noise"标签识别为一个特殊值，例如-1
y = np.array([label if label != b'noise' else -1 for label in data1['label']], dtype=int)
cluster_num = len(np.unique(y[y != -1]))  # 排除noise后计算唯一标签数量
print(cluster_num)
# 数据归一化
data = (data - np.amin(data, axis=0)) / (np.amax(data, axis=0) - np.amin(data, axis=0))


# 加载聚类结果mat文件
cluster_labels_data = scio.loadmat('Labels.mat')
# 提取clusterLabels
cluster_labels = cluster_labels_data['clusterLabels'].squeeze()

valid_indices = y != -1
valid_y = y[valid_indices]
valid_cluster_labels = cluster_labels[valid_indices]

ARI, NMI, ACC = compute_score(valid_cluster_labels, valid_y)
print('ARI: {a:.2f}\nNMI: {b:.2f}\nACC: {c:.2f}'.format(a=ARI, b=NMI, c=ACC))

plt.figure(figsize=(16, 12))
plt.scatter(data[:, 0], data[:, 1], c=cluster_labels, cmap='viridis')
plt.title("DLORE-DP", fontsize=30)
plt.xlabel("X coordinate", fontsize=20)
plt.ylabel("Y coordinate", fontsize=20)
plt.show()