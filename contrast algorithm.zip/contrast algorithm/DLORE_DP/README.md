# DLORE-DP
The matlab code and synthetic data sets for " Dense members of local cores-based density peaks clustering algorithm [J], Knowledge-Based Systems, 2020, 193: 105454." 
DLORE_DP.m includes DLORE-DP algorithm (Algorithm 4 of the manuscript), CoreSearch_supk.m includes Algorithm 2 and Algorithm 3. DP.m is used to cluster local cores. drawcluster2 is used to draw the clustering result. SNNDPC2.m includes the SNN-DPC algorithm we compared with in the experiment. Synthetic data sets pacake includes the synthetic data sets we used in the experiment
