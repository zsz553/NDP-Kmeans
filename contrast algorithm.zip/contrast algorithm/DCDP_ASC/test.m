% 读取整个k文件
dataset_k = readtable('D:/Artificial Intelligence/Data/dataset_k2.xlsx');
% 数据根目录
root_path = 'D:\Artificial Intelligence\Data\RealWorld_mat';
% 用于存储运行结果
df_list ={};
bad_list ={};
% 遍历并输出文件夹下的所有文件
for k = 1:height(dataset_k)
    fileName = dataset_k{k,'Var1'}{1};
    K = dataset_k{k,'Var2'};
    fullPath = fullfile(root_path, fileName);
    data1=load(fullPath);
    keys = fieldnames(data1);
    data = data1.(keys{1});
    % Normalize the data
    data = (data - min(data, [], 1)) ./ (max(data, [], 1) - min(data, [], 1) + 1e-15);
    labesl = data1.(keys{2});
    [N, d] = size(data);
    if size(data,1)>3000
        continue;
    end
    num_cluster = length(unique(labels));
    try
        Label = USPEC(data, num_cluster,'euclidean',1000,K);
    catch ME
        bad_list(end+1,:)={fileName};
        continue;
    end
    [statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(Label,labels);
    row_data = {fileName,K,ACC*100,NMI*100,ARI*100};
    disp(row_data);
    df_list(end+1, :) = row_data;
    % 转换为表格
    df1 = cell2table(df_list,'VariableNames', {'dataset', 'k', 'ACC', 'NMI', 'ARI'});
    writetable(df1, 'USPEC_output.xlsx');
    df2 = cell2table(bad_list);
    writetable(df2, 'USPEC_bad_output.xlsx');
end