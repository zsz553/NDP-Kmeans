function [Xsorted, Dsorted] = eigsorts(X, di)
    % 从对角矩阵di中提取特征值
    eigenvalues = diag(di);
    
    % 对特征值进行排序，并获取排序索引
    [sortedValues, sortIndex] = sort(eigenvalues);
    
    % 使用排序索引来排序特征向量
    Xsorted = X(:, sortIndex);
    
    % 创建一个新的排序后的对角特征值矩阵
    Dsorted = diag(sortedValues);
end
