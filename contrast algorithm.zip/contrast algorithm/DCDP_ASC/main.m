% % Load the .mat file
% data1 = load('D:\Artificial intelligence\Machine_Learning\Data\RealWorld_mat\semeionEW.mat');
%
% % Extract the 'data' field
% keys = fieldnames(data1);
% data = data1.(keys{1});
% labels = data1.(keys{2});
% % Get the size of the data
% [n, d] = size(data);
% % Get the number of unique clusters
% cluster_num = numel(unique(labels));
% disp(cluster_num);
% % Normalize the data
% data = (data - min(data, [], 1)) ./ (max(data, [], 1) - min(data, [], 1) + 1e-15);
% [cl, core_dist] = DCDP_ASC(data,0);
% [statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(cl,labels);
% fprintf('%.2f\t%.2f\t%.2f\n', ARI*100, NMI*100, ACC*100);

% Synthetic数据txt
root_path = '../datasets/';
data_name = 'Jain';
data_labels = load(fullfile(root_path, [data_name '.txt']));
X = data_labels(:, 1:end-1);
Y = data_labels(:, end);
[n, d] = size(X);
X = (X - min(X(:))) / (max(X(:)) - min(X(:)));
cluster_num=length(unique(Y));
fprintf('------------------data_name:%s   shape:(%d,%d)   cluster_num:%d----------------', data_name,n,d,cluster_num);
[cl, core_dist] = DCDP_ASC(X,0);
[statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(cl,Y);
fprintf('ARI:%.2f\tNMI:%.2f\tACC:%.2f\n', ARI*100, NMI*100, ACC*100);
