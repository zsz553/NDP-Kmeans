import numpy as np
from sklearn.metrics import normalized_mutual_info_score
from sklearn.metrics import adjusted_mutual_info_score, adjusted_rand_score, fowlkes_mallows_score
from scipy.optimize import linear_sum_assignment
import scipy.io as scio
import matplotlib.pyplot as plt

def compute_score(y_last, y):
    NMI = normalized_mutual_info_score(y, y_last) * 100
    ARI = adjusted_rand_score(y, y_last) * 100
    ACC = cluster_accuracy(y, y_last) * 100
    return ARI, NMI, ACC

def cluster_accuracy(y_true, y_pred):
    y_true = y_true.astype(np.int64)
    assert y_pred.size == y_true.size
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    ind = linear_sum_assignment(w.max() - w)
    ind = np.array(ind).T
    return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size


data1 = scio.loadmat(r"C:\\研究生\\聚类\\聚类研究\\realworld\\UCI\\D155.mat")
data = data1['data']
data = data.astype(np.float32)
n, d = data.shape
print(n, d)
y = data1['labels']
y = y.reshape(y.shape[0])
cluster_num = len(np.unique(y))
print(cluster_num)
data = (data - np.amin(data, axis=0)) / (np.amax(data, axis=0) - np.amin(data, axis=0) + 1e-15)


# 加载聚类结果mat文件
cluster_labels_data = scio.loadmat('Labels.mat')
# 提取clusterLabels
cluster_labels = cluster_labels_data['cl'].squeeze()

valid_indices = y != -1
valid_y = y[valid_indices]
valid_cluster_labels = cluster_labels[valid_indices]

ARI, NMI, ACC = compute_score(valid_cluster_labels, valid_y)
print('ARI: {a:.2f}\nNMI: {b:.2f}\nACC: {c:.2f}'.format(a=ARI, b=NMI, c=ACC))

"""
plt.figure(figsize=(16, 12))
plt.scatter(data[:, 0], data[:, 1], c=cluster_labels, cmap='viridis')
plt.title("DCDP-ASC", fontsize=30)
plt.xlabel("X coordinate", fontsize=20)
plt.ylabel("Y coordinate", fontsize=20)
plt.show()
"""